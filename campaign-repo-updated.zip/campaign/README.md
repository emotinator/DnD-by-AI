# Campaign repo

Canonical record for the campaign run with Claude as DM / co-DM.

| Path | What | In Claude project knowledge? |
|---|---|---|
| `instructions.md` | DM Project Instructions (export from the doc) | Pasted into project instructions |
| `bible.md` | World, factions, NPCs, threads, DM-only secrets | Yes |
| `roster.md` | PCs, D&D Beyond IDs, house items, takeaways | Yes |
| `house-rules.md` | Rulings, homebrew, lines and veils | Yes |
| `log-recent.md` | Rolling summary of the current arc | Yes |
| `module-notes.md` | Only if running a published adventure | Yes, if present |
| `sessions/` | One file per session, never edited after confirmation | No, read on demand |
| `archive/` | Arc summaries, old prep (`prep/`), player chronicles (`chronicles/`), maps | No, read on demand |

**After each session:** add the new `sessions/` file, replace the changed living files, and commit with the message `Session YYYY-MM-DD: <title>`.
